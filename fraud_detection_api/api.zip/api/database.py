# api/database.py
import os
import logging
from motor.motor_asyncio import AsyncIOMotorClient
from typing import AsyncGenerator

logger = logging.getLogger(__name__)

# Use environment variable or default local MongoDB
MONGODB_URI = os.getenv("MONGODB_URI", "mongodb://localhost:27017")
MONGO_DB_NAME = os.getenv("MONGO_DB_NAME", "fraud_detection_db")
MONGO_PREDICTION_COLLECTION = os.getenv("MONGO_PREDICTION_COLLECTION", "predictions")

client: AsyncIOMotorClient | None = None
db = None

def get_mongo_uri_info():
    return {"uri": MONGODB_URI, "db": MONGO_DB_NAME, "collection": MONGO_PREDICTION_COLLECTION}

async def connect_to_mongo():
    global client, db
    if client is None:
        logger.info(f"Connecting to MongoDB at: {MONGODB_URI}")
        client = AsyncIOMotorClient(MONGODB_URI, serverSelectionTimeoutMS=5000)
        db = client[MONGO_DB_NAME]
        # Optionally create indexes here
        try:
            await db[MONGO_PREDICTION_COLLECTION].create_index("transaction_id", unique=True)
        except Exception as e:
            logger.warning(f"Could not create index (okay if exists): {e}")

async def close_mongo_connection():
    global client
    if client:
        client.close()
        client = None

# Dependency for FastAPI endpoints
async def get_db() -> AsyncGenerator:
    """
    Dependency that yields a Motor database object.
    Usage in endpoint: db = Depends(get_db) -> use db as Motor Database (async)
    """
    if client is None:
        await connect_to_mongo()
    try:
        yield db
    finally:
        # do not close client here; close on app shutdown
        pass
