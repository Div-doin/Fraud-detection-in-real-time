# fraud-detection-api/api/main.py
"""
Fraud Detection API (MongoDB + FastAPI, async)
- Loads a pre-trained CatBoost model (joblib bundle).
- Accepts preprocessed/scaled features (as in training).
- Logs predictions to MongoDB (async motor).
"""

from fastapi import FastAPI, HTTPException, Depends, Header
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field, ConfigDict
from typing import List, Optional, Union, Any
from pathlib import Path
from datetime import datetime
import joblib
import pandas as pd
import numpy as np
import os
import time
import logging
import asyncio

# Optional: Azure Application Insights log exporter (non-blocking if not installed)
try:
    from opencensus.ext.azure.log_exporter import AzureLogHandler
    AZURE_INSIGHTS_AVAILABLE = True
except Exception:
    AZURE_INSIGHTS_AVAILABLE = False

# Async MongoDB utilities (must be provided in api/database.py)
# Expected functions/variables from api/database.py:
#   connect_to_mongo(), close_mongo_connection(), get_db() (dependency),
#   MONGO_PREDICTION_COLLECTION
try:
    from api.database import (
        connect_to_mongo,
        close_mongo_connection,
        get_db as get_mongo_db,
        get_mongo_uri_info,
        MONGO_PREDICTION_COLLECTION,
    )
    MONGO_AVAILABLE = True
except Exception as e:
    get_mongo_db = None
    connect_to_mongo = None
    close_mongo_connection = None
    get_mongo_uri_info = None
    MONGO_PREDICTION_COLLECTION = "predictions"
    MONGO_AVAILABLE = False
    # (We won't raise — DB is optional; we handle absence gracefully.)

# Configure logging (file + console)
LOG_DIR = Path(__file__).parent.parent / "logs"
LOG_DIR.mkdir(parents=True, exist_ok=True)
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    handlers=[
        logging.FileHandler(LOG_DIR / "api.log"),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

# If Azure App Insights connection string exists, attach handler (optional)
if AZURE_INSIGHTS_AVAILABLE and os.getenv("APPLICATIONINSIGHTS_CONNECTION_STRING"):
    try:
        handler = AzureLogHandler(connection_string=os.getenv("APPLICATIONINSIGHTS_CONNECTION_STRING"))
        logger.addHandler(handler)
        logger.info("Azure Application Insights handler attached")
    except Exception as e:
        logger.warning(f"Could not attach AzureLogHandler: {e}")

# FastAPI app
app = FastAPI(
    title="Fraud Detection API",
    description="Real-time fraud detection using CatBoost model (preprocessed features)",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=os.getenv("ALLOWED_ORIGINS", "*").split(","),
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Config
MODEL_DIR = Path(__file__).parent.parent / "models"
MODEL_PATH = os.getenv("MODEL_PATH", str(MODEL_DIR / "Variant III_CatBoost.pkl"))
API_KEY = os.getenv("API_KEY", None)
MONGO_URI_INFO = get_mongo_uri_info() if get_mongo_uri_info else None

# Load model (synchronously on import)
model = None
threshold = 0.5
expected_features: List[str] = []

try:
    if not Path(MODEL_PATH).exists():
        logger.error(f"Model file not found at: {MODEL_PATH}")
    else:
        bundle = joblib.load(MODEL_PATH)
        # bundle may be dict with 'model' and 'threshold' or a raw model
        if isinstance(bundle, dict):
            model = bundle.get("model", None)
            threshold = float(bundle.get("threshold", 0.5))
        else:
            model = bundle
            threshold = float(getattr(bundle, "threshold", 0.5))

        # Detect expected features if model exposes them
        if model is not None and hasattr(model, "feature_names_"):
            try:
                expected_features = list(model.feature_names_) or []
            except Exception:
                expected_features = []
        else:
            expected_features = []

        logger.info(f"Model loaded: {MODEL_PATH}")
        logger.info(f"Threshold: {threshold}, expected_features_count: {len(expected_features)}")
except Exception as e:
    logger.exception("Failed to load model")
    model = None
    threshold = 0.5
    expected_features = []

# --- Utility functions ---

def verify_api_key(x_api_key: Optional[str] = Header(None)) -> Optional[str]:
    """Verify API key if configured (synchronous)"""
    if API_KEY and x_api_key != API_KEY:
        logger.warning("Invalid API key attempt")
        raise HTTPException(status_code=403, detail="Invalid API Key")
    return x_api_key

async def get_db_dependency():
    """FastAPI dependency that yields an async Motor DB object or None."""
    if MONGO_AVAILABLE and get_mongo_db:
        async for db in get_mongo_db():
            yield db
            return
    else:
        # yield None so endpoints can operate without DB
        yield None

def determine_risk_level(prob: float) -> str:
    if prob < 0.3:
        return "LOW"
    if prob < 0.6:
        return "MEDIUM"
    if prob < 0.8:
        return "HIGH"
    return "CRITICAL"

# Debug endpoint for model features
@app.get("/debug/model_features")
async def debug_model_features():
    return {
        "model_loaded": model is not None,
        "model_path": str(MODEL_PATH),
        "expected_features_count": len(expected_features),
        "expected_features_sample": expected_features[:20] if expected_features else "Not available",
        "mongo_available": MONGO_AVAILABLE,
        "mongo_uri_info": MONGO_URI_INFO
    }

# --- Startup / Shutdown events ---
@app.on_event("startup")
async def startup_event():
    logger.info("Starting Fraud Detection API...")
    if MONGO_AVAILABLE and connect_to_mongo:
        try:
            await connect_to_mongo()
            logger.info("Connected to MongoDB")
        except Exception as e:
            logger.warning(f"Could not connect to MongoDB on startup: {e}")

@app.on_event("shutdown")
async def shutdown_event():
    logger.info("Shutting down Fraud Detection API...")
    if MONGO_AVAILABLE and close_mongo_connection:
        try:
            await close_mongo_connection()
            logger.info("MongoDB connection closed")
        except Exception as e:
            logger.warning(f"Error closing MongoDB connection: {e}")

# --- Pydantic models (preprocessed inputs) ---
class Transaction(BaseModel):
    model_config = ConfigDict(
        json_schema_extra={"example": {}}  # keep minimal here
    )
    # All features are floats (preprocessed / scaled)
    income: float
    name_email_similarity: float
    prev_address_months_count: float
    current_address_months_count: float
    customer_age: float
    days_since_request: float
    intended_balcon_amount: float
    payment_type: float
    zip_count_4w: float
    velocity_6h: float
    velocity_24h: float
    velocity_4w: float
    bank_branch_count_8w: float
    date_of_birth_distinct_emails_4w: float
    employment_status: float
    credit_risk_score: float
    email_is_free: float
    housing_status: float
    phone_home_valid: float
    phone_mobile_valid: float
    bank_months_count: float
    has_other_cards: float
    proposed_credit_limit: float
    foreign_request: float
    source: float
    session_length_in_minutes: float
    device_os: float
    keep_alive_session: float
    device_distinct_emails_8w: float
    device_fraud_count: float
    month: float
    # Additional generic placeholders (if model expects x1/x2)
    x1: Optional[float] = None
    x2: Optional[float] = None

class PredictionResponse(BaseModel):
    transaction_id: str
    is_fraud: bool
    fraud_probability: float
    risk_level: str
    threshold_used: float
    timestamp: str
    model_version: str
    processing_time_ms: float

class BatchTransaction(BaseModel):
    transactions: List[Transaction]

# --- Endpoints ---

@app.get("/")
async def root():
    return {
        "service": "Fraud Detection API",
        "status": "online",
        "model_loaded": model is not None,
        "expected_features_count": len(expected_features),
        "mongo_available": MONGO_AVAILABLE,
        "timestamp": datetime.utcnow().isoformat()
    }

@app.get("/health")
async def health_check():
    if model is None:
        raise HTTPException(status_code=503, detail="Model not loaded")
    return {
        "status": "healthy",
        "model_loaded": True,
        "model_path": str(MODEL_PATH),
        "threshold": float(threshold),
        "expected_features_count": len(expected_features),
        "mongo_available": MONGO_AVAILABLE,
        "timestamp": datetime.utcnow().isoformat()
    }

@app.get("/model/info")
async def model_info(api_key: str = Depends(verify_api_key)):
    if model is None:
        raise HTTPException(status_code=503, detail="Model not loaded")
    return {
        "model_type": type(model).__name__,
        "model_version": "1.0",
        "training_dataset": "Variant III",
        "threshold": float(threshold),
        "features_count": len(expected_features),
        "expected_features": expected_features if expected_features else "Not available",
        "accepts_preprocessed_data": True,
        "model_path": str(MODEL_PATH),
    }

@app.post("/predict", response_model=PredictionResponse)
async def predict_fraud(
    transaction: Transaction,
    db = Depends(get_db_dependency),
    api_key: str = Depends(verify_api_key),
):
    if model is None:
        raise HTTPException(status_code=503, detail="Model not loaded")

    start_time = time.time()

    try:
        # Build DataFrame from input
        transaction_dict = transaction.model_dump()
        df = pd.DataFrame([transaction_dict])

        # If model expects feature names, attempt to reorder columns accordingly;
        # otherwise we will use df.values (position-based)
        use_values = False
        if expected_features:
            missing = [f for f in expected_features if f not in df.columns]
            if missing:
                # If some expected features are missing, log and fall back
                logger.warning(f"Missing features from input compared to model: {missing}")
                # If a large portion is missing, safer to use .values but warn
                # We'll still try to use the intersection in the expected order.
            # compute available features in model order
            available_features = [f for f in expected_features if f in df.columns]
            if len(available_features) == 0:
                # nothing matches -> use values
                use_values = True
            else:
                df_for_pred = df[available_features]
        else:
            use_values = True

        # Prepare data for prediction
        try:
            if use_values:
                X_input = df.values
            else:
                X_input = df_for_pred
        except Exception as e:
            logger.exception("Failed to prepare input for prediction")
            raise HTTPException(status_code=500, detail=f"Input preparation failed: {e}")

        # Predict: try DataFrame first if model supports named features, else use .values
        try:
            if not use_values and hasattr(model, "feature_names_") and model.feature_names_:
                fraud_probability = float(model.predict_proba(X_input)[0, 1])
            else:
                fraud_probability = float(model.predict_proba(X_input if isinstance(X_input, np.ndarray) else X_input.values)[0, 1])
        except Exception as e:
            logger.error("Prediction call failed. Input columns: %s; expected_features_count: %d; error: %s",
                         list(df.columns), len(expected_features), e, exc_info=True)
            raise HTTPException(status_code=500, detail=f"Prediction failed: {str(e)}")

        is_fraud = bool(fraud_probability >= threshold)
        risk_level = determine_risk_level(fraud_probability)
        transaction_id = f"TXN_{datetime.utcnow().strftime('%Y%m%d%H%M%S%f')}"
        processing_time = (time.time() - start_time) * 1000.0

        # Async log into MongoDB if available (do not block on failure)
        if MONGO_AVAILABLE and db is not None:
            try:
                log_doc = {
                    "transaction_id": transaction_id,
                    "payload": transaction_dict,
                    "fraud_probability": float(fraud_probability),
                    "is_fraud": is_fraud,
                    "risk_level": risk_level,
                    "threshold": float(threshold),
                    "processing_time_ms": processing_time,
                    "timestamp": datetime.utcnow()
                }
                # fire-and-forget insert
                asyncio.create_task(db[MONGO_PREDICTION_COLLECTION].insert_one(log_doc))
            except Exception as e:
                logger.warning(f"Could not write prediction log to MongoDB: {e}")

        # Application logging
        logger.info(
            f"Prediction {transaction_id} | fraud={is_fraud} | prob={fraud_probability:.4f} | time={processing_time:.2f}ms"
        )

        return PredictionResponse(
            transaction_id=transaction_id,
            is_fraud=is_fraud,
            fraud_probability=float(fraud_probability),
            risk_level=risk_level,
            threshold_used=float(threshold),
            timestamp=datetime.utcnow().isoformat(),
            model_version=getattr(model, "__class__", type(model)).__name__ if model else "unknown",
            processing_time_ms=processing_time
        )

    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Unexpected error during prediction")
        raise HTTPException(status_code=500, detail=f"Prediction error: {str(e)}")

@app.post("/predict/batch")
async def predict_batch(
    batch: BatchTransaction,
    db = Depends(get_db_dependency),
    api_key: str = Depends(verify_api_key),
):
    if model is None:
        raise HTTPException(status_code=503, detail="Model not loaded")

    start_time = time.time()

    try:
        df = pd.DataFrame([t.model_dump() for t in batch.transactions])

        use_values = False
        if expected_features:
            available_features = [f for f in expected_features if f in df.columns]
            if len(available_features) == 0:
                use_values = True
            else:
                df_for_pred = df[available_features]
        else:
            use_values = True

        if use_values:
            X_input = df.values
        else:
            X_input = df_for_pred

        try:
            if not use_values and hasattr(model, "feature_names_") and model.feature_names_:
                probabilities = model.predict_proba(X_input)[:, 1]
            else:
                probabilities = model.predict_proba(X_input if isinstance(X_input, np.ndarray) else X_input.values)[:, 1]
        except Exception as e:
            logger.exception("Batch prediction failed")
            raise HTTPException(status_code=500, detail=f"Batch prediction failed: {e}")

        predictions = (probabilities >= threshold).astype(bool)

        results = []
        docs_to_insert = []
        for idx, (prob, pred) in enumerate(zip(probabilities, predictions)):
            risk = determine_risk_level(float(prob))
            results.append({
                "transaction_index": idx,
                "is_fraud": bool(pred),
                "fraud_probability": float(prob),
                "risk_level": risk
            })
            # prepare log doc for mongo
            if MONGO_AVAILABLE and db is not None:
                docs_to_insert.append({
                    "transaction_id": f"TXN_{datetime.utcnow().strftime('%Y%m%d%H%M%S%f')}_{idx}",
                    "payload": batch.transactions[idx].model_dump(),
                    "fraud_probability": float(prob),
                    "is_fraud": bool(pred),
                    "risk_level": risk,
                    "threshold": float(threshold),
                    "processing_time_ms": None,
                    "timestamp": datetime.utcnow()
                })

        # async insert many if db available
        if MONGO_AVAILABLE and db is not None and docs_to_insert:
            try:
                asyncio.create_task(db[MONGO_PREDICTION_COLLECTION].insert_many(docs_to_insert))
            except Exception as e:
                logger.warning(f"Failed to insert batch logs to MongoDB: {e}")

        processing_time = (time.time() - start_time) * 1000.0
        logger.info(f"Batch processed: size={len(results)} frauds={sum(r['is_fraud'] for r in results)} time_ms={processing_time:.2f}")

        return {
            "total_transactions": len(results),
            "fraudulent_count": sum(r["is_fraud"] for r in results),
            "processing_time_ms": processing_time,
            "predictions": results,
            "timestamp": datetime.utcnow().isoformat()
        }

    except HTTPException:
        raise
    except Exception as e:
        logger.exception("Unexpected batch error")
        raise HTTPException(status_code=500, detail=f"Batch prediction failed: {e}")

# Analytics endpoints using MongoDB aggregations
@app.get("/analytics/summary")
async def analytics_summary(
    db = Depends(get_db_dependency),
    api_key: str = Depends(verify_api_key)
):
    if not MONGO_AVAILABLE or db is None:
        raise HTTPException(status_code=503, detail="Database not available")

    try:
        coll = db[MONGO_PREDICTION_COLLECTION]
        total = await coll.count_documents({})
        fraud_count = await coll.count_documents({"is_fraud": True})
        avg_prob_cursor = coll.aggregate([
            {"$group": {"_id": None, "avg_prob": {"$avg": "$fraud_probability"}}}
        ])
        avg_prob_res = await avg_prob_cursor.to_list(length=1)
        avg_prob = avg_prob_res[0]["avg_prob"] if avg_prob_res else 0.0

        avg_time_cursor = coll.aggregate([
            {"$match": {"processing_time_ms": {"$ne": None}}},
            {"$group": {"_id": None, "avg_time": {"$avg": "$processing_time_ms"}}}
        ])
        avg_time_res = await avg_time_cursor.to_list(length=1)
        avg_time = avg_time_res[0]["avg_time"] if avg_time_res else 0.0

        # risk distribution
        risk_cursor = coll.aggregate([
            {"$group": {"_id": "$risk_level", "count": {"$sum": 1}}}
        ])
        risk_list = await risk_cursor.to_list(length=100)
        risk_distribution = {r["_id"]: r["count"] for r in risk_list}

        return {
            "total_transactions": total,
            "fraud_count": fraud_count,
            "fraud_rate": (fraud_count / total * 100) if total > 0 else 0,
            "avg_fraud_probability": float(avg_prob),
            "avg_response_time_ms": float(avg_time),
            "risk_distribution": risk_distribution,
            "timestamp": datetime.utcnow().isoformat()
        }

    except Exception as e:
        logger.exception("Analytics summary failed")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/analytics/recent")
async def analytics_recent(
    limit: int = 50,
    db = Depends(get_db_dependency),
    api_key: str = Depends(verify_api_key)
):
    if not MONGO_AVAILABLE or db is None:
        raise HTTPException(status_code=503, detail="Database not available")

    try:
        coll = db[MONGO_PREDICTION_COLLECTION]
        cursor = coll.find().sort("timestamp", -1).limit(limit)
        docs = await cursor.to_list(length=limit)
        results = [{
            "transaction_id": doc.get("transaction_id"),
            "timestamp": doc.get("timestamp").isoformat() if doc.get("timestamp") else None,
            "is_fraud": doc.get("is_fraud"),
            "fraud_probability": doc.get("fraud_probability"),
            "risk_level": doc.get("risk_level"),
            "processing_time_ms": doc.get("processing_time_ms")
        } for doc in docs]

        return {"count": len(results), "transactions": results}
    except Exception as e:
        logger.exception("Analytics recent failed")
        raise HTTPException(status_code=500, detail=str(e))

# Run with uvicorn: uvicorn api.main:app --reload
if __name__ == "__main__":
    import uvicorn
    port = int(os.getenv("PORT", 8000))
    uvicorn.run("api.main:app", host="0.0.0.0", port=port, reload=True, log_level="info")
